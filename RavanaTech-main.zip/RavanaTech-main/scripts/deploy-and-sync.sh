#!/bin/bash
set -e

echo "=== 1. Building Production Web App ==="
npm run build

echo "=== 2. Deploying to Firebase Hosting (raavanaatec.web.app) ==="
npx firebase deploy --only hosting --token "1//0gDkQamHpmxYbCgYIARAAGBASNwF-L9Ir7sdRz03kL00KAmV6MNQdVH8IdMqo0rpkBbJtV5dwtkteC_7hYVgE9HfzoMAwUKls0As" --non-interactive

echo "=== 3. Pushing Changes to GitHub (ravanatech-official/RavanaTech) ==="
git add .
git commit -m "deploy: update live site and sync to github [$(date +'%Y-%m-%d %H:%M:%S')]" || echo "No git changes to commit"
git push origin main

echo "=== ALL DONE: Firebase Live & GitHub Synced! ==="
