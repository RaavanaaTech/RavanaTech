import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Globe, 
  MapPin, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  ChevronRight, 
  ArrowRight, 
  PhoneCall, 
  RotateCcw, 
  CheckCircle2, 
  Zap, 
  ShoppingBag, 
  UtensilsCrossed, 
  CalendarCheck, 
  Building2, 
  Bot, 
  ExternalLink,
  Minimize2,
  Maximize2,
  Headphones,
  HeartHandshake,
  ShieldCheck,
  Send,
  Coffee,
  Lightbulb,
  TrendingUp,
  Coins,
  Smile,
  Phone,
  MessageSquare,
  Video
} from 'lucide-react';
import founderAvatarImg from '../../assets/founder-avatar.jpg';
import { db } from '../../firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

// Web Audio API Synthesizer for tactile feedback
const playHoloSound = (type: 'beep' | 'chime' | 'warp' | 'success') => {
  if (typeof window === 'undefined') return;
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;
    if (type === 'beep') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.08);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      osc.start(now);
      osc.stop(now + 0.08);
    } else if (type === 'chime') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.exponentialRampToValueAtTime(1046.5, now + 0.15);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'warp') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.2);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    } else if (type === 'success') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.setValueAtTime(659.25, now + 0.1);
      osc.frequency.setValueAtTime(880, now + 0.2);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
    }
  } catch (err) {}
};

interface VoiceScript {
  en: string;
  siText: string;
  siPhonetic: string;
}

const VOICE_SCRIPTS: Record<string, VoiceScript> = {
  map_prompt: {
    en: "Welcome to Ravana Tech. Please click or tap your location on the map to calibrate your experience.",
    siText: "රාවණා ටෙක් වෙත සාදරයෙන් පිළිගන්නවා. කරුණාකර ඔබගේ ස්ථානය තෝරන්න.",
    siPhonetic: "Welcome to Ravana Tech. Karunaakara obage sthaanaya thoranna."
  },
  welcome: {
    en: "Hey there! Welcome to Ravana Tech. I am your digital architect and founder. I build ultra high-converting digital platforms, web applications, and custom AI automation. Tell me, what great vision brought you here today?",
    siText: "ආයුබෝවන්! රාවණා ටෙක් වෙත සාදරයෙන් පිළිගන්නවා. මම ඔබගේ Digital Architect. අපි high-converting වෙබ් අඩවි සහ AI Automations නිර්මාණය කරනවා. අද ඔබ බලාපොරොත්තු වන විශේෂිත Project එක මොකක්ද?",
    siPhonetic: "Aayubowan! Ravana Tech wetha saadharayen pili-gannawa. Mama obage Digital Architect. Api high-converting web adavi saha AI automations nirmanaya karanawa. Ada oba balaaporoththu vana visheshitha Project eka mokakda?"
  },
  starter_step: {
    en: "Don't worry about technical knowledge or budget worries at all. Here you get 100% free friendly guidance to kickstart your idea. Select your preference below.",
    siText: "තාක්ෂණික දැනුම හෝ මුදල් ගැන කිසිම බයක් ඇති කරගන්න එපා. මෙතනදී අපි ඔබට 100% ක් නොමිලේ සුහදව මඟ පෙන්වනවා. ඔබට ගැළපෙන අංශය තෝරන්න.",
    siPhonetic: "Thakshanika danuma ho mudal gana kisima bayak athi karaganna epaa. Methanadee api obata 100%k nomile suhadawa maga penwanawa. Obata galapena anshaya thoranna."
  },
  growth_step: {
    en: "Awesome! Let's get more customers from Google and Facebook straight into your WhatsApp. Choose your business type below.",
    siText: "නියමයි! ඔබේ ආයතනයට Google සහ Facebook හරහා එන පාරිභෝගිකයින් කෙළින්ම WhatsApp එකට ගෙන්වා ගැනීමේ පහසුම ක්‍රමය මෙන්න. ඔබේ ව්‍යාපාර වර්ගය තෝරන්න.",
    siPhonetic: "Niyamayi! Obe aayathanayata Google saha Facebook harahaa ena customersla kelinma WhatsApp ekata genvaagaaneeme kramaya menna. Obe vyapaara vargaya thoranna."
  },
  demos_step: {
    en: "Seeing is believing! Test our 5 live, real-world interactive applications right now directly on your phone.",
    siText: "කතා කරනවාට වඩා අපේ වැඩ ඇස් දෙකෙන්ම බලන්න. මෙන්න සජීවීව ක්‍රියාත්මක වන Real-world Demo Apps 5ක්. ඔබම Click කරලා බලන්න.",
    siPhonetic: "Katha karanawata wadaa ape wada as dekenma balanna. Menna sajeeweeva kriyaathmaka vana Real world Demo Apps 5k. Obama click karala balanna."
  },
  pricing_step: {
    en: "100% honest and transparent pricing with zero hidden fees. Select your comfortable budget range below.",
    siText: "අපි ළඟ කිසිම හංගපු ගාස්තු නෑ. ඔබට දැරිය හැකි සාධාරණ මුදලට වැඩේ කරගත හැකි ආකාරය මෙන්න. ඔබේ Budget එකට ගැළපෙන එක තෝරන්න.",
    siPhonetic: "Api langa kisima hangapu gaasthu nae. Obata daeriya haki saadharana mudalata wade karagatha haki aakaraya menna. Obe budget ekata galapena eka thoranna."
  },
  human_step: {
    en: "No tech jargon needed! I am Shanthapriya Silva. Feel free to send a voice note, message, or request a call. I am here to help you like a friend.",
    siText: "යාළුවේ, ඔයාට තාක්ෂණය නොතේරුණාට කමක් නෑ. මම ශාන්තප්‍රිය සිල්වා. මට කෙළින්ම කතා කරන්න. සහෝදරයෙක් වගේ මම ඔයාගේ ප්‍රශ්න අහගෙන ඉන්නවා.",
    siPhonetic: "Yaluwe, oyata thakshanaya notherunata kamak nae. Mama Shanthapriya Silva. Mata kelinma katha karanna. Sahodaroyek wage mama oyage prashna ahagena innawa."
  },
  plan_ready: {
    en: "Congratulations! Your project plan is customized with total care. Tap below to send it directly to my WhatsApp!",
    siText: "සුබ පැතුම්! ඔබගේ ව්‍යාපෘති සැලැස්ම සූදානම්. දැන්ම මගේ WhatsApp එකට යවා නොමිලේ සාකච්ඡා කරමු!",
    siPhonetic: "Suba pathum! Obage vyapaara salasama soodaanam. Danma mage WhatsApp ekata yawa nomile saakachcha karamu!"
  }
};

type ReceptionistStage = 
  | 'map_selection'
  | 'root_situations'
  // Branch 1: Starter
  | 'starter_sub'
  | 'starter_final'
  // Branch 2: Growth
  | 'growth_sub'
  | 'growth_final'
  // Branch 3: Demos
  | 'demos_grid'
  // Branch 4: Pricing
  | 'pricing_sub'
  | 'pricing_final'
  // Branch 5: Human Support
  | 'human_sub'
  | 'callback_success';

export const VirtualCyberReceptionist: React.FC = () => {
  const navigate = useNavigate();

  // Navigation & Language
  const [hasInteracted, setHasInteracted] = useState(false);
  const [stage, setStage] = useState<ReceptionistStage>('map_selection');
  const [isMinimized, setIsMinimized] = useState(false);
  const [selectedRegion, setSelectedRegion] = useState<'lk' | 'global' | null>(null);
  const [language, setLanguage] = useState<'en' | 'si'>('en');
  const [voiceMuted, setVoiceMuted] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Selected details across funnels
  const [selectedItemTitle, setSelectedItemTitle] = useState<string>('');
  const [selectedItemDesc, setSelectedItemDesc] = useState<string>('');
  const [selectedItemPrice, setSelectedItemPrice] = useState<string>('');
  const [callbackName, setCallbackName] = useState<string>('');
  const [callbackPhone, setCallbackPhone] = useState<string>('');
  const [callbackNote, setCallbackNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const synthRef = useRef<SpeechSynthesis | null>(null);

  // Initialize Speech Synthesis
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Universal Bulletproof Voice Narration
  const speakScript = (key: keyof typeof VOICE_SCRIPTS, lang: 'en' | 'si') => {
    if (voiceMuted || !synthRef.current) return;
    const script = VOICE_SCRIPTS[key];
    if (!script) return;

    try {
      synthRef.current.cancel();
    } catch (e) {}

    setTimeout(() => {
      if (!synthRef.current || voiceMuted) return;

      try {
        const voices = synthRef.current.getVoices();
        let utterance: SpeechSynthesisUtterance;

        if (lang === 'si') {
          const nativeSiVoice = voices.find(v => 
            v.lang.toLowerCase().startsWith('si') || 
            v.name.toLowerCase().includes('sinhala')
          );

          if (nativeSiVoice) {
            utterance = new SpeechSynthesisUtterance(script.siText);
            utterance.voice = nativeSiVoice;
            utterance.lang = nativeSiVoice.lang;
            utterance.rate = 0.95;
            utterance.pitch = 1.0;
          } else {
            utterance = new SpeechSynthesisUtterance(script.siPhonetic);
            utterance.lang = 'en-IN';
            utterance.rate = 0.92;
            utterance.pitch = 1.05;

            const southAsianVoice = voices.find(v => 
              v.lang.includes('en-IN') || 
              v.name.toLowerCase().includes('india') || 
              v.name.toLowerCase().includes('hindi') || 
              v.name.toLowerCase().includes('ravi') || 
              v.name.toLowerCase().includes('heera') ||
              v.name.toLowerCase().includes('google') ||
              v.name.toLowerCase().includes('natural')
            );
            if (southAsianVoice) {
              utterance.voice = southAsianVoice;
            }
          }
        } else {
          utterance = new SpeechSynthesisUtterance(script.en);
          utterance.lang = 'en-US';
          utterance.rate = 1.0;
          utterance.pitch = 1.0;

          const enVoice = voices.find(v => 
            v.name.includes('Google') || 
            v.name.includes('Natural') || 
            v.name.includes('Daniel') || 
            v.name.includes('Samantha') || 
            v.lang === 'en-US'
          );
          if (enVoice) utterance.voice = enVoice;
        }

        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);

        synthRef.current.speak(utterance);
      } catch (err) {
        setIsSpeaking(false);
      }
    }, 60);
  };

  // Initial Map Arrival Audio
  useEffect(() => {
    const timer = setTimeout(() => {
      if (stage === 'map_selection' && !hasInteracted && !voiceMuted) {
        speakScript('map_prompt', 'en');
      }
    }, 800);
    return () => clearTimeout(timer);
  }, [stage, hasInteracted, voiceMuted]);

  // Handle Location Selection
  const handleSelectLocation = (region: 'lk' | 'global') => {
    playHoloSound('chime');
    setHasInteracted(true);
    setSelectedRegion(region);

    const chosenLang = region === 'lk' ? 'si' : 'en';
    setLanguage(chosenLang);
    setStage('root_situations');

    if (synthRef.current) {
      try { synthRef.current.cancel(); } catch (e) {}
    }

    setTimeout(() => {
      speakScript('welcome', chosenLang);
    }, 250);
  };

  // Toggle Language
  const toggleLanguage = () => {
    playHoloSound('beep');
    const nextLang = language === 'en' ? 'si' : 'en';
    setLanguage(nextLang);

    if (stage === 'root_situations') {
      speakScript('welcome', nextLang);
    }
  };

  // Toggle Voice Mute
  const toggleVoice = () => {
    if (!voiceMuted) {
      if (synthRef.current) synthRef.current.cancel();
      setIsSpeaking(false);
      setVoiceMuted(true);
    } else {
      setVoiceMuted(false);
      playHoloSound('beep');
      speakScript('welcome', language);
    }
  };

  // Reset to Situations Root
  const handleReset = () => {
    playHoloSound('beep');
    setStage('root_situations');
    setSelectedItemTitle('');
    setSelectedItemDesc('');
    setSelectedItemPrice('');
    speakScript('welcome', language);
  };

  // Save Callback Request to Firestore
  const handleCallbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!callbackName.trim() || !callbackPhone.trim()) return;

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'inquiries'), {
        name: callbackName,
        phone: callbackPhone,
        notes: callbackNote || 'Virtual Cyber Reception Direct Callback Request',
        source: 'cyber_reception_human_help',
        createdAt: serverTimestamp(),
      });
      playHoloSound('success');
      setStage('callback_success');
    } catch (err) {
      console.warn('Inquiry submit error:', err);
      // Even if Firestore is restricted, give the client the direct WhatsApp link
      playHoloSound('success');
      setStage('callback_success');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getCustomWhatsAppUrl = (topic: string, details: string, price: string = '') => {
    const lines = [
      `*Hi Ravana Tech (Founder Shanthapriya Silva),*`,
      `I am reaching out via your Virtual Cyber Reception:`,
      `• *My Goal/Situation:* ${topic}`,
      `• *Selected Path:* ${details}`,
      price ? `• *Estimated Budget Tier:* ${price}` : '',
      `• *Direct WhatsApp Line:* +94 78 847 0610`,
      ``,
      `Can we have a friendly conversation to get started?`
    ].filter(Boolean);

    return `https://wa.me/94788470610?text=${encodeURIComponent(lines.join('\n'))}`;
  };

  // Minimized Cyber Assistant Badge
  if (isMinimized) {
    return (
      <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-50 flex items-center gap-3">
        <button
          onClick={() => {
            playHoloSound('chime');
            setIsMinimized(false);
          }}
          className="group flex items-center gap-3 px-4 py-3 rounded-2xl bg-stone-950/95 border-2 border-amber-500/50 shadow-2xl text-stone-100 hover:border-amber-400 hover:scale-105 transition-all cursor-pointer backdrop-blur-xl"
        >
          <div className="relative w-10 h-10 rounded-full overflow-hidden border border-amber-400 bg-stone-900 shrink-0">
            <img src={founderAvatarImg} alt="Founder Avatar" className="w-full h-full object-cover object-top" />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-stone-950 animate-pulse" />
          </div>
          <div className="text-left">
            <span className="text-[10px] font-bold text-amber-400 tracking-wider uppercase flex items-center gap-1">
              Virtual Guide Active <Sparkles className="w-3 h-3 text-amber-300" />
            </span>
            <span className="text-xs font-semibold text-stone-200 group-hover:text-amber-300 transition-colors">
              Click to Re-open Guided Help
            </span>
          </div>
          <Maximize2 className="w-4 h-4 text-stone-400 group-hover:text-amber-400 ml-1" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-stone-950/95 backdrop-blur-2xl overflow-y-auto animate-in fade-in duration-300">
      
      {/* BACKGROUND HOLOGRAM GLOW */}
      <div className="absolute inset-0 bg-[radial-gradient(#amber-500/10_1px,transparent_1px)] [background-size:24px_24px] opacity-40 pointer-events-none" />
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

      {/* CONTAINER */}
      <div className="relative w-full max-w-4xl bg-stone-900/90 border border-amber-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col my-auto backdrop-blur-xl">
        
        {/* HEADER */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 bg-stone-950/80 border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-mono text-xs uppercase tracking-widest text-amber-400 font-bold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Ravana Tech • Friendly Guided Reception
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleLanguage}
              className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold border border-stone-700 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span>{language === 'en' ? 'සිංහල' : 'English'}</span>
            </button>

            <button
              onClick={toggleVoice}
              title={voiceMuted ? "Unmute Voice" : "Mute Voice"}
              className={`p-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                voiceMuted ? 'bg-rose-500/15 border-rose-500/30 text-rose-400' : 'bg-stone-800 border-stone-700 text-amber-400'
              }`}
            >
              {voiceMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className={`w-4 h-4 ${isSpeaking ? 'animate-bounce' : ''}`} />}
            </button>

            <button
              onClick={() => {
                playHoloSound('beep');
                setIsMinimized(true);
              }}
              title="Minimize to browse site"
              className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-200 border border-stone-700 transition-colors cursor-pointer"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* STAGE 0: WORLD MAP LOCATION RADAR */}
        {/* ========================================================================= */}
        {stage === 'map_selection' && (
          <div className="p-6 sm:p-10 text-center space-y-6 animate-in zoom-in-95 duration-400">
            <div className="space-y-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 uppercase tracking-widest">
                <Globe className="w-3.5 h-3.5" />
                Global Location Radar
              </span>
              <h2 className="text-xl sm:text-3xl font-extrabold text-stone-100 tracking-tight">
                Click or Tap Your Location to Enter
              </h2>
              <p className="text-xs sm:text-sm text-stone-400 max-w-xl mx-auto">
                Select your region. We automatically set the language and currency for you.
              </p>
            </div>

            <div className="relative max-w-2xl mx-auto p-4 sm:p-6 rounded-2xl bg-stone-950/80 border border-stone-800 shadow-inner flex flex-col items-center">
              <div className="relative w-full h-48 sm:h-64 rounded-xl overflow-hidden bg-gradient-to-b from-stone-900 via-stone-950 to-stone-950 border border-stone-800/80 flex items-center justify-center">
                <svg viewBox="0 0 1000 500" className="w-full h-full opacity-35 text-stone-500 fill-current">
                  <path d="M150,120 Q180,80 250,90 T350,150 T280,240 T180,220 Z M220,280 Q250,260 270,300 T260,420 T200,380 Z M450,100 Q520,60 580,100 T530,200 T440,160 Z M460,220 Q540,200 560,280 T540,400 T460,350 Z M650,80 Q800,70 850,150 T750,250 T620,180 Z M750,300 Q840,280 870,350 T800,420 T720,380 Z" />
                </svg>

                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <span className="w-32 h-32 rounded-full border border-amber-500/20 animate-ping opacity-40" />
                  <span className="w-56 h-56 rounded-full border border-amber-500/10" />
                  <span className="w-80 h-80 rounded-full border border-amber-500/5" />
                </div>

                {/* PIN: SRI LANKA */}
                <button
                  onClick={() => handleSelectLocation('lk')}
                  className="absolute left-[62%] top-[62%] -translate-x-1/2 -translate-y-1/2 group cursor-pointer p-2 focus:outline-none"
                  title="Sri Lanka (ශ්‍රී ලංකාව)"
                >
                  <span className="relative flex h-6 w-6 items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-stone-950 shadow-lg group-hover:scale-125 transition-transform"></span>
                  </span>
                  <div className="absolute left-1/2 -translate-x-1/2 mt-1 px-2.5 py-1 rounded-md bg-emerald-500 text-stone-950 font-extrabold text-[10px] whitespace-nowrap shadow-lg">
                    🇱🇰 Sri Lanka (ශ්‍රී ලංකාව)
                  </div>
                </button>

                {/* PIN: GLOBAL */}
                <button
                  onClick={() => handleSelectLocation('global')}
                  className="absolute left-[24%] top-[34%] group cursor-pointer p-2 focus:outline-none"
                  title="USA / Americas"
                >
                  <span className="relative flex h-5 w-5 items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-sky-500 border-2 border-stone-950 shadow-lg group-hover:scale-125 transition-transform"></span>
                  </span>
                  <div className="absolute left-1/2 -translate-x-1/2 mt-1 px-2 py-0.5 rounded-md bg-stone-900 border border-sky-400/50 text-sky-300 font-bold text-[9px] whitespace-nowrap">
                    🇺🇸 USA / Americas
                  </div>
                </button>

                <button
                  onClick={() => handleSelectLocation('global')}
                  className="absolute left-[50%] top-[25%] group cursor-pointer p-2 focus:outline-none"
                  title="UK / Europe"
                >
                  <span className="relative flex h-5 w-5 items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-sky-500 border-2 border-stone-950 shadow-lg group-hover:scale-125 transition-transform"></span>
                  </span>
                  <div className="absolute left-1/2 -translate-x-1/2 mt-1 px-2 py-0.5 rounded-md bg-stone-900 border border-sky-400/50 text-sky-300 font-bold text-[9px] whitespace-nowrap">
                    🇬🇧 UK / Europe
                  </div>
                </button>
              </div>

              <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                <button
                  onClick={() => handleSelectLocation('lk')}
                  className="p-4 rounded-xl bg-gradient-to-r from-emerald-600/30 to-emerald-700/20 hover:from-emerald-600/40 hover:to-emerald-700/30 border-2 border-emerald-500/60 hover:border-emerald-400 text-left transition-all group cursor-pointer flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">🇱🇰</span>
                    <div>
                      <div className="font-extrabold text-sm text-stone-100 group-hover:text-emerald-300 flex items-center gap-1.5">
                        <span>Sri Lanka (ශ්‍රී ලංකාව)</span>
                        <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-1.5 py-0.5 rounded font-mono">සිංහල Auto</span>
                      </div>
                      <span className="text-xs text-stone-400 block mt-0.5">
                        Local business websites, PayHere, & LKR pricing
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-emerald-400 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => handleSelectLocation('global')}
                  className="p-4 rounded-xl bg-gradient-to-r from-sky-600/25 to-blue-700/15 hover:from-sky-600/35 hover:to-blue-700/25 border-2 border-sky-500/50 hover:border-sky-400 text-left transition-all group cursor-pointer flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">🌍</span>
                    <div>
                      <div className="font-extrabold text-sm text-stone-100 group-hover:text-sky-300 flex items-center gap-1.5">
                        <span>International / Global</span>
                        <span className="text-[10px] bg-sky-500/30 text-sky-300 px-1.5 py-0.5 rounded font-mono">English Auto</span>
                      </div>
                      <span className="text-xs text-stone-400 block mt-0.5">
                        Global SaaS, Exports, Stripe, & USD pricing
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-sky-400 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STAGE 1: 5 HUMAN-CENTERED ROOT SITUATIONS (Zero Jargon) */}
        {/* ========================================================================= */}
        {stage === 'root_situations' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in fade-in duration-300">
            {/* AVATAR PODIUM */}
            <div className="relative rounded-2xl bg-gradient-to-r from-stone-950 via-stone-900 to-stone-950 border border-stone-800 p-4 sm:p-6 flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left shadow-xl">
              <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-3xl overflow-hidden border-2 border-amber-400/80 bg-stone-950 shrink-0 shadow-2xl group">
                <img 
                  src={founderAvatarImg} 
                  alt="Founder Shanthapriya Silva" 
                  className={`w-full h-full object-cover object-top transition-transform duration-500 ${isSpeaking ? 'scale-105' : ''}`}
                />
                {isSpeaking && (
                  <div className="absolute inset-x-0 bottom-0 bg-stone-950/80 py-1 flex items-center justify-center gap-1">
                    <span className="w-1 h-3 bg-amber-400 rounded-full animate-pulse" />
                    <span className="w-1 h-5 bg-amber-300 rounded-full animate-pulse delay-75" />
                    <span className="w-1 h-2 bg-amber-400 rounded-full animate-pulse delay-150" />
                  </div>
                )}
              </div>

              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-center sm:justify-between gap-2">
                  <span className="text-[11px] font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    Shanthapriya Silva • Digital Architect & Founder
                  </span>
                  {isSpeaking && (
                    <span className="text-[10px] text-amber-300/80 font-mono animate-pulse">Voice Active • Live</span>
                  )}
                </div>

                <p className="text-sm sm:text-base text-stone-100 font-sans leading-relaxed">
                  "{language === 'si' 
                    ? "ආයුබෝවන්! රාවණා ටෙක් වෙත සාදරයෙන් පිළිගන්නවා. මම ඔබගේ Digital Architect. අපි high-converting වෙබ් අඩවි සහ AI Automations නිර්මාණය කරනවා. අද ඔබ බලාපොරොත්තු වන විශේෂිත Project එක මොකක්ද?"
                    : "Hey there! Welcome to Ravana Tech. I am your digital architect and founder. I build ultra high-converting digital platforms, web applications, and custom AI automation. Tell me, what great vision brought you here today?"
                  }"
                </p>

                <div className="flex items-center justify-center sm:justify-start gap-3 pt-1">
                  <button
                    onClick={() => speakScript('welcome', language)}
                    className="inline-flex items-center gap-1 text-xs text-stone-400 hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    <Headphones className="w-3.5 h-3.5" />
                    <span>{language === 'si' ? 'නැවත අසන්න (Replay Voice)' : 'Replay Welcome Audio'}</span>
                  </button>

                  <span className="text-stone-600">•</span>

                  <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    {selectedRegion === 'lk' ? '🇱🇰 ශ්‍රී ලංකාව' : '🌍 Global'}
                  </span>
                </div>
              </div>
            </div>

            {/* THE 5 ZERO-OVERTHINKING HUMAN PATHS */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">
                  {language === 'si' ? 'ඔබට වඩාත්ම ගැළපෙන අංකය තෝරන්න:' : 'Select Your Situation from the 5 Options Below:'}
                </span>
                <span className="text-[11px] text-stone-500 font-mono">100% Free Consultation</span>
              </div>

              {/* Option 1: Starter / New Idea */}
              <button
                onClick={() => {
                  playHoloSound('beep');
                  setStage('starter_sub');
                  speakScript('starter_step', language);
                }}
                className="w-full p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-stone-900 to-stone-900 hover:from-amber-500/25 hover:border-amber-400 border border-amber-500/30 text-left transition-all group cursor-pointer flex items-center gap-4 hover:translate-x-1"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-extrabold text-lg shrink-0">
                  1
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-extrabold text-sm sm:text-base text-stone-100 group-hover:text-amber-300 flex items-center gap-2">
                    <span>{language === 'si' ? '🌱 මට අලුත් ව්‍යාපාරයක් හෝ අදහසක් තියෙනවා — මුල සිට සරලව පටන් ගන්න ඕනේ' : '🌱 I am starting a new business or idea — Guide me from scratch'}</span>
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {language === 'si' ? 'තාක්ෂණික දැනුම නැතත් කිසිම බයක් නෑ. අපි ඔබව අතින් අල්ලාගෙන මුල සිටම මඟ පෙන්වනවා.' : 'Zero tech knowledge required. We build and guide you through every step.'}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-amber-400 group-hover:translate-x-1 transition-transform shrink-0" />
              </button>

              {/* Option 2: Existing Shop / Business Sales */}
              <button
                onClick={() => {
                  playHoloSound('beep');
                  setStage('growth_sub');
                  speakScript('growth_step', language);
                }}
                className="w-full p-4 rounded-2xl bg-stone-900/80 hover:bg-stone-850 hover:border-sky-500/50 border border-stone-800 text-left transition-all group cursor-pointer flex items-center gap-4 hover:translate-x-1"
              >
                <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-500/40 text-sky-400 flex items-center justify-center font-extrabold text-lg shrink-0">
                  2
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-extrabold text-sm sm:text-base text-stone-100 group-hover:text-sky-300">
                    {language === 'si' ? '🚀 මට දැනටමත් Shop එකක් / Business එකක් තියෙනවා — Sales & Customers වැඩි කරගන්න ඕනේ' : '🚀 I have an existing business — I want more customers & online orders'}
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {language === 'si' ? 'Facebook, Google සහ WhatsApp හරහා වැඩිපුර Orders සහ Clients ගෙන්වා ගැනීමට.' : 'Drive Google, Facebook, and WhatsApp traffic into real paying clients.'}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-stone-400 group-hover:text-sky-400 group-hover:translate-x-1 transition-transform shrink-0" />
              </button>

              {/* Option 3: Real Working Demos */}
              <button
                onClick={() => {
                  playHoloSound('beep');
                  setStage('demos_grid');
                  speakScript('demos_step', language);
                }}
                className="w-full p-4 rounded-2xl bg-stone-900/80 hover:bg-stone-850 hover:border-emerald-500/50 border border-stone-800 text-left transition-all group cursor-pointer flex items-center gap-4 hover:translate-x-1"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-extrabold text-lg shrink-0">
                  3
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-extrabold text-sm sm:text-base text-stone-100 group-hover:text-emerald-300 flex items-center gap-2">
                    <span>{language === 'si' ? '🎮 වැඩ කරන සැබෑ Websites මගේ Phone එකෙන්ම බලන්න ඕනේ' : '🎮 Test Real Working Sample Websites on My Phone'}</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono hidden sm:inline">5 Live Demos</span>
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {language === 'si' ? 'Bakery, Cafe, Salon, Plant Shop, Real Estate සජීවීව Click කරලා අත්හදා බලන්න.' : 'Interactive Bakery Cake builder, Cafe menus, Salon slots, Plant shop.'}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-stone-400 group-hover:text-emerald-400 group-hover:translate-x-1 transition-transform shrink-0" />
              </button>

              {/* Option 4: Transparent Honest Pricing */}
              <button
                onClick={() => {
                  playHoloSound('beep');
                  setStage('pricing_sub');
                  speakScript('pricing_step', language);
                }}
                className="w-full p-4 rounded-2xl bg-stone-900/80 hover:bg-stone-850 hover:border-purple-500/50 border border-stone-800 text-left transition-all group cursor-pointer flex items-center gap-4 hover:translate-x-1"
              >
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-400 flex items-center justify-center font-extrabold text-lg shrink-0">
                  4
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-extrabold text-sm sm:text-base text-stone-100 group-hover:text-purple-300">
                    {language === 'si' ? '💰 ගණන් හිලව් කොහොමද? මගේ Budget එකට ගැළපෙන පැකේජ් එකක් දැනගන්න ඕනේ' : '💰 Honest Pricing & Budget Calculator — No Hidden Fees'}
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {language === 'si' ? 'කිසිම හංගපු ගාස්තු නෑ. Domain, Hosting, Design සියල්ල සමඟ සාධාරණ මිල ගණන්.' : 'Clear pricing tiers with free domain, hosting, and zero surprise fees.'}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-stone-400 group-hover:text-purple-400 group-hover:translate-x-1 transition-transform shrink-0" />
              </button>

              {/* Option 5: Direct Human Support */}
              <button
                onClick={() => {
                  playHoloSound('beep');
                  setStage('human_sub');
                  speakScript('human_step', language);
                }}
                className="w-full p-4 rounded-2xl bg-gradient-to-r from-emerald-600/20 via-stone-900 to-stone-900 hover:from-emerald-600/30 hover:border-emerald-400 border border-emerald-500/40 text-left transition-all group cursor-pointer flex items-center gap-4 hover:translate-x-1"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-extrabold text-lg shrink-0">
                  5
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-extrabold text-sm sm:text-base text-emerald-300 flex items-center gap-2">
                    <HeartHandshake className="w-4 h-4" />
                    <span>{language === 'si' ? '🤝 මට තාක්ෂණික දේවල් තේරෙන්නේ නෑ — මට කෙළින්ම මනුස්සයෙක් එක්ක කතා කරන්න ඕනේ!' : '🤝 I don\'t know tech — I just want to speak with a helpful human friend!'}</span>
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {language === 'si' ? 'සහෝදරයෙක් වගේ මට කෙළින්ම කතා කරන්න. මම ශාන්තප්‍රිය සිල්වා (+94 78 847 0610).' : 'Speak directly with founder Shanthapriya Silva. No bots, pure human guidance.'}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-emerald-400 group-hover:translate-x-1 transition-transform shrink-0" />
              </button>
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 text-center border-t border-stone-800 flex items-center justify-between">
              <button
                onClick={() => setStage('map_selection')}
                className="text-xs text-stone-400 hover:text-stone-200 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{language === 'si' ? 'රට නැවත තෝරන්න' : 'Change Location'}</span>
              </button>

              <button
                onClick={() => {
                  playHoloSound('beep');
                  setIsMinimized(true);
                }}
                className="text-xs font-semibold text-amber-400 hover:text-amber-300 underline cursor-pointer"
              >
                {language === 'si' ? 'සාමාන්‍ය වෙබ් අඩවිය බලන්න (Browse Full Site)' : 'Explore Traditional Website'}
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* BRANCH 1: STARTER / NEW BUSINESS (5 Sub-Options) */}
        {/* ========================================================================= */}
        {stage === 'starter_sub' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block">Step 2 of 3 • New Idea / Starter</span>
                <h3 className="text-base sm:text-lg font-extrabold text-stone-100">
                  {language === 'si' ? 'ඔබ පටන් ගන්න බලාපොරොත්තු වන අංශය තෝරන්න:' : 'Select What Best Describes Your Starting Idea:'}
                </h3>
              </div>
              <button onClick={handleReset} className="text-xs text-stone-400 hover:text-stone-200 underline cursor-pointer">
                Back to 5 Options
              </button>
            </div>

            <div className="space-y-2.5">
              {[
                { id: '1', title: '1. සරලව තමන් ගැන සහ සේවාවන් පෙන්වන 1-Page Site එකක්', en: '1. Clean 1-Page Starter Portfolio or Business Profile', desc: 'පුංචියට, ලස්සනට පටන් ගන්න අයට.', badge: '100% නොමිලේ මඟ පෙන්වීම', badgeEn: '100% Free Guidance' },
                { id: '2', title: '2. Phone එකෙන් Orders ගන්න පුංචි WhatsApp Online Shop එකක්', en: '2. Mobile WhatsApp Ordering Mini-Store', desc: 'කේක්, ඇඳුම්, පැල, බඩු විකුණන්න.', badge: 'නොමිලේ අදහස් & සැලැස්ම', badgeEn: 'Free Strategy Plan' },
                { id: '3', title: '3. Salon, Classes, හෝ Repair සේවාවක් සඳහා Appointments ගන්න', en: '3. Service Appointments & Time Slot Booking', desc: 'පාරිභෝගිකයින්ට දින වෙන් කරගැනීමට.', badge: 'පහසු Booking උපදෙස්', badgeEn: 'Zero-Risk Advice' },
                { id: '4', title: '4. මට මොකක්ද ඕනේ කියලා තාම හිතාගන්න බෑ — අදහස් සහ උපදෙස් ඕනේ', en: '4. I am not sure yet — I need ideas & honest advice', desc: 'අදහසක් නැති අයට මුල සිට සුහදව මඟ පෙන්වීම.', badge: '100% නොමිලේ උපදෙස්', badgeEn: '100% Free Advice' },
                { id: '5', title: '5. කිසිම වියදමක් නැතිව Founder සමඟ නොමිලේ සැලැස්මක් සාකච්ඡා කරමු', en: '5. Plan a Custom Idea Directly with Founder Shanthapriya', desc: 'ඔබේ අදහසට ගැළපෙනම නිවැරදි සැලැස්ම නොමිලේ.', badge: 'Founder සමඟ සුහද කතාබහක්', badgeEn: 'Friendly 1-on-1 Chat' },
              ].map(sub => (
                <button
                  key={sub.id}
                  onClick={() => {
                    playHoloSound('chime');
                    setSelectedItemTitle(sub.title);
                    setSelectedItemDesc(sub.desc);
                    setSelectedItemPrice(language === 'si' ? sub.badge : sub.badgeEn);
                    setStage('starter_final');
                    speakScript('plan_ready', language);
                  }}
                  className="w-full p-3.5 rounded-xl bg-stone-950/80 hover:bg-stone-900 border border-stone-800 hover:border-emerald-400 text-left transition-all group cursor-pointer flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-stone-100 group-hover:text-emerald-300">
                      {language === 'si' ? sub.title : sub.en}
                    </div>
                    <span className="text-[11px] text-stone-400 mt-0.5 block">{sub.desc}</span>
                  </div>
                  <div className="text-right shrink-0 ml-3">
                    <span className="text-[11px] font-medium text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20 block">
                      {language === 'si' ? sub.badge : sub.badgeEn}
                    </span>
                    <span className="text-[10px] text-stone-500 flex items-center justify-end gap-1 mt-1 group-hover:text-emerald-300">
                      තෝරන්න <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* BRANCH 1 FINAL: STARTER COMPLETE PLAN (100% Free & Friendly) */}
        {stage === 'starter_final' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in zoom-in-95 duration-300">
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-stone-900 to-emerald-500/10 border border-emerald-500/40 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-400 block">
                  100% Free Friendly Consultation Guaranteed
                </span>
                <h3 className="text-base sm:text-lg font-extrabold text-stone-100">
                  {selectedItemTitle}
                </h3>
                <span className="text-xs text-stone-300">
                  මූලික සාකච්ඡාව: <strong className="text-emerald-400">100% නොමිලේ (කිසිදු මුදල් අයකිරීමක් නැත)</strong>
                </span>
              </div>
              <button onClick={() => setStage('starter_sub')} className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-300 text-xs font-semibold cursor-pointer">
                වෙනස් කරන්න
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-stone-950/80 border border-stone-800 space-y-2 text-xs text-stone-300">
              <span className="font-bold text-stone-200 block">අපගේ සහෝදරත්වයේ සහතිකය (No Risk Guarantee):</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /><span>100% නොමිලේ අදහස් සහ තාක්ෂණික මඟ පෙන්වීම</span></div>
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /><span>ඔබට දැරිය හැකි මුදලකට පමණක් අනාගතයේදී පටන් ගැනීමේ නිදහස</span></div>
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /><span>කිසිදු බලපෑමක් හෝ හදිස්සි කිරීමක් නොමැත</span></div>
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /><span>කෙළින්ම Founder Shanthapriya Silva සමඟ සුහද කතාබහක්</span></div>
              </div>
            </div>

            <div className="space-y-3">
              <a
                href={getCustomWhatsAppUrl('Starting a New Idea / Starter Business (100% Free Friendly Guidance)', selectedItemTitle, '100% Free Consultation')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg hover:scale-[1.01] transition-all cursor-pointer"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Founder සමඟ 100% නොමිලේ සුහදව සාකච්ඡා කරමු (+94 78 847 0610)</span>
              </a>

              <div className="flex items-center justify-between text-xs">
                <button onClick={handleReset} className="text-stone-400 hover:text-stone-200 underline cursor-pointer">
                  Start from Beginning
                </button>
                <button onClick={() => setIsMinimized(true)} className="text-amber-400 hover:text-amber-300 underline cursor-pointer">
                  Browse Traditional Website
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* BRANCH 2: EXISTING BUSINESS & SALES (5 Sub-Options) */}
        {/* ========================================================================= */}
        {stage === 'growth_sub' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-sky-400 uppercase tracking-widest block">Step 2 of 3 • Business Growth</span>
                <h3 className="text-base sm:text-lg font-extrabold text-stone-100">
                  {language === 'si' ? 'ඔබේ ව්‍යාපාර ක්ෂේත්‍රය තෝරන්න:' : 'Select Your Business Industry for Maximum Sales Growth:'}
                </h3>
              </div>
              <button onClick={handleReset} className="text-xs text-stone-400 hover:text-stone-200 underline cursor-pointer">
                Back to 5 Options
              </button>
            </div>

            <div className="space-y-2.5">
              {[
                { id: '1', title: '1. කෑම කඩ, Bakery, Cafe & Restaurant (Digital Menu + Orders)', en: '1. Food, Bakery & Cafe (Interactive Menu & Instant WhatsApp Cart)', desc: 'Instagram & Facebook හරහා එන අය කෙළින්ම කෑම ඇනවුම් කිරීමට.', price: 'LKR 35,000 - 45,000 ($140)' },
                { id: '2', title: '2. ඇඳුම්, පැල, බඩු විකුණන Online Shop (PayHere / Card Payment)', en: '2. Retail & E-Commerce (Direct Card Payments to Bank)', desc: 'පාරිභෝගිකයින්ට Card එකෙන් ගෙවන්න සහ Stock බලන්න.', price: 'LKR 45,000 - 55,000 ($180)' },
                { id: '3', title: '3. Salon, Spa, Clinics හෝ Services (Live Slot Booking)', en: '3. Salon, Spa & Clinic Online Appointment System', desc: 'Call කර කර ඉන්නේ නැතිව clientsලටම වේලාවන් වෙන් කරගන්න.', price: 'LKR 30,000 - 40,000 ($120)' },
                { id: '4', title: '4. ඉඩම්, ගෙවල්, Export හෝ Corporate (High-End Authority)', en: '4. Real Estate, Exports & Corporate High-Ticket Authority', desc: 'දේශීය සහ විදේශීය clientsලාට ඉහළම විශ්වාසය ගොඩනැගීමට.', price: 'LKR 50,000 - 75,000 ($200)' },
                { id: '5', title: '5. පාරිභෝගිකයින්ට පැය 24ම උත්තර දෙන 24/7 AI WhatsApp Auto-Reply', en: '5. 24/7 Automated AI WhatsApp Sales Closer', desc: 'ඔබ නිදාගෙන ඉද්දිත් orders ගන්නා ස්වයංක්‍රීය පද්ධතිය.', price: 'LKR 30,000 - 42,000 ($130)' },
              ].map(sub => (
                <button
                  key={sub.id}
                  onClick={() => {
                    playHoloSound('chime');
                    setSelectedItemTitle(sub.title);
                    setSelectedItemDesc(sub.desc);
                    setSelectedItemPrice(sub.price);
                    setStage('growth_final');
                    speakScript('plan_ready', language);
                  }}
                  className="w-full p-3.5 rounded-xl bg-stone-950/80 hover:bg-stone-900 border border-stone-800 hover:border-sky-400 text-left transition-all group cursor-pointer flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-stone-100 group-hover:text-sky-300">
                      {language === 'si' ? sub.title : sub.en}
                    </div>
                    <span className="text-[11px] text-stone-400 mt-0.5 block">{sub.desc}</span>
                  </div>
                  <div className="text-right shrink-0 ml-3">
                    <span className="text-[11px] font-mono text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20 block">{sub.price}</span>
                    <span className="text-[10px] text-stone-500 flex items-center justify-end gap-1 mt-1 group-hover:text-sky-300">
                      Select <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* BRANCH 2 FINAL: GROWTH PLAN */}
        {stage === 'growth_final' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in zoom-in-95 duration-300">
            <div className="p-4 rounded-2xl bg-gradient-to-r from-sky-500/20 via-stone-900 to-sky-500/10 border border-sky-500/40 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-sky-400 block">
                  Tailored Business Growth Architecture
                </span>
                <h3 className="text-base sm:text-lg font-extrabold text-stone-100">
                  {selectedItemTitle}
                </h3>
                <span className="text-xs text-stone-300">
                  Investment Estimate: <strong className="text-sky-400">{selectedItemPrice}</strong>
                </span>
              </div>
              <button onClick={() => setStage('growth_sub')} className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-300 text-xs font-semibold cursor-pointer">
                Change Selection
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-stone-950/80 border border-stone-800 space-y-2 text-xs text-stone-300">
              <span className="font-bold text-stone-200 block">Business Growth Features Included:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /><span>Google Search & Google Maps Local SEO Ranking</span></div>
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /><span>Direct 1-Tap WhatsApp Checkout Engine</span></div>
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /><span>High-speed Mobile First UX for Instagram/FB Ads</span></div>
                <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /><span>Zero Monthly Maintenance Fees & 1 Year Support</span></div>
              </div>
            </div>

            <div className="space-y-3">
              <a
                href={getCustomWhatsAppUrl('Existing Business Growth Plan', selectedItemTitle, selectedItemPrice)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg hover:scale-[1.01] transition-all cursor-pointer"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Launch This Growth Plan with Founder on WhatsApp (+94 78 847 0610)</span>
              </a>

              <div className="flex items-center justify-between text-xs">
                <button onClick={handleReset} className="text-stone-400 hover:text-stone-200 underline cursor-pointer">
                  Start from Beginning
                </button>
                <button onClick={() => setIsMinimized(true)} className="text-amber-400 hover:text-amber-300 underline cursor-pointer">
                  Browse Traditional Website
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* BRANCH 3: 5 LIVE WORKING DEMOS */}
        {/* ========================================================================= */}
        {stage === 'demos_grid' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest block">Live Experience</span>
                <h3 className="text-base sm:text-lg font-extrabold text-stone-100">
                  {language === 'si' ? 'අත්හදා බැලීමට පහත Demo එකක් තෝරන්න:' : 'Test Any Real Working Application on Your Device:'}
                </h3>
              </div>
              <button onClick={handleReset} className="text-xs text-stone-400 hover:text-stone-200 underline cursor-pointer">
                Back to 5 Options
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { slug: 'bakery', icon: '🥖', title: '1. Artisan Bakery & Cakes', desc: 'Custom cake builder, flavour selection, 1-tap cart', badge: 'Interactive Cake Builder' },
                { slug: 'cafe', icon: '☕', title: '2. Urban Specialty Cafe', desc: 'Digital food menu, coffee customization, direct order', badge: 'Digital Menu & Table Orders' },
                { slug: 'salon', icon: '✂️', title: '3. Aura Luxury Salon', desc: 'Live stylist choosing, time slot booking, service prices', badge: 'Online Appointment Engine' },
                { slug: 'flora', icon: '🌿', title: '4. Flora Plant Nursery', desc: 'Online shopping cart, price calculations, plant catalog', badge: 'E-Commerce Retail Store' },
                { slug: 'real-estate', icon: '🏡', title: '5. Sovereign Real Estate', desc: 'Luxury villas, property tours, VIP client inquiry', badge: 'High-Ticket Property Showcase' },
              ].map(demo => (
                <button
                  key={demo.slug}
                  onClick={() => {
                    playHoloSound('warp');
                    navigate(`/demo/${demo.slug}`);
                    setIsMinimized(true);
                  }}
                  className="p-4 rounded-xl bg-stone-950 hover:bg-stone-900 border border-stone-800 hover:border-emerald-500 text-left transition-all group cursor-pointer"
                >
                  <div className="flex items-start gap-3">
                    <span className="text-2xl p-2 rounded-lg bg-stone-900 border border-stone-800">{demo.icon}</span>
                    <div className="flex-1">
                      <div className="font-bold text-xs sm:text-sm text-stone-200 group-hover:text-emerald-300">
                        {demo.title}
                      </div>
                      <span className="text-[11px] text-stone-400 block mt-0.5">{demo.desc}</span>
                      <div className="mt-2 text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                        <span>Launch Live App Right Now</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <div className="pt-2 text-center text-xs text-stone-400">
              <span>Like what you see? We can deploy your branded version in 3 to 5 days!</span>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* BRANCH 4: TRANSPARENT HONEST PRICING (5 Sub-Options) */}
        {/* ========================================================================= */}
        {stage === 'pricing_sub' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest block">Zero Hidden Fees • 100% Transparent</span>
                <h3 className="text-base sm:text-lg font-extrabold text-stone-100">
                  {language === 'si' ? 'ඔබේ Budget එකට ගැළපෙන සාධාරණ පැකේජය තෝරන්න:' : 'Select Your Budget Tier for Transparent Pricing:'}
                </h3>
              </div>
              <button onClick={handleReset} className="text-xs text-stone-400 hover:text-stone-200 underline cursor-pointer">
                Back to 5 Options
              </button>
            </div>

            <div className="space-y-2.5">
              {[
                { id: '1', title: '1. Starter Business Web (රු. 20,000 - 28,000)', en: '1. Starter Business Platform (LKR 20,000 - 28,000 / $80)', desc: 'නොමිලේ Domain (.com/.lk), Free 1 Year Hosting, Google Search Setup.', price: 'LKR 20k - 28k' },
                { id: '2', title: '2. WhatsApp Online Ordering Shop (රු. 32,000 - 45,000)', en: '2. WhatsApp Online Store with Cart (LKR 32,000 - 45,000 / $130)', desc: 'කෑම, ඇඳුම්, බඩු සඳහා සම්පූර්ණ 1-Tap WhatsApp Cart පද්ධතිය.', price: 'LKR 32k - 45k' },
                { id: '3', title: '3. Full Card Payment E-Commerce (රු. 45,000 - 65,000)', en: '3. Full E-Commerce with Card Payment (LKR 45,000 - 65,000 / $180)', desc: 'PayHere හෝ Stripe හරහා කෙළින්ම Bank Account එකට සල්ලි එන්න.', price: 'LKR 45k - 65k' },
                { id: '4', title: '4. 24/7 AI WhatsApp Auto-Reply System (රු. 25,000 - 38,000)', en: '4. 24/7 AI WhatsApp Sales Bot (LKR 25,000 - 38,000 / $110)', desc: 'පාරිභෝගිකයින්ට ස්වයංක්‍රීයව පිළිතුරු දෙන කෘත්‍රිම බුද්ධි සහායකයා.', price: 'LKR 25k - 38k' },
                { id: '5', title: '5. මගේ Budget එකට ගැළපෙන Custom Package එකක් සාකච්ඡා කරමු', en: '5. Tailor a Custom Deal Fitting My Exact Budget', desc: 'ඔබේ අතේ ඇති මුදලට ගැලපෙන හොඳම විසඳුම මිත්‍රශීලීව සාකච්ඡා කරමු.', price: 'Friendly Discussion' },
              ].map(sub => (
                <button
                  key={sub.id}
                  onClick={() => {
                    playHoloSound('chime');
                    setSelectedItemTitle(sub.title);
                    setSelectedItemDesc(sub.desc);
                    setSelectedItemPrice(sub.price);
                    setStage('pricing_final');
                    speakScript('plan_ready', language);
                  }}
                  className="w-full p-3.5 rounded-xl bg-stone-950/80 hover:bg-stone-900 border border-stone-800 hover:border-purple-400 text-left transition-all group cursor-pointer flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-stone-100 group-hover:text-purple-300">
                      {language === 'si' ? sub.title : sub.en}
                    </div>
                    <span className="text-[11px] text-stone-400 mt-0.5 block">{sub.desc}</span>
                  </div>
                  <div className="text-right shrink-0 ml-3">
                    <span className="text-[11px] font-mono text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20 block">{sub.price}</span>
                    <span className="text-[10px] text-stone-500 flex items-center justify-end gap-1 mt-1 group-hover:text-purple-300">
                      Select <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* BRANCH 4 FINAL: PRICING BREAKDOWN */}
        {stage === 'pricing_final' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in zoom-in-95 duration-300">
            <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-500/20 via-stone-900 to-purple-500/10 border border-purple-500/40 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-purple-400 block">
                  Honest Pricing Breakdown Locked
                </span>
                <h3 className="text-base sm:text-lg font-extrabold text-stone-100">
                  {selectedItemTitle}
                </h3>
                <span className="text-xs text-stone-300">
                  Target Price Range: <strong className="text-purple-400">{selectedItemPrice}</strong>
                </span>
              </div>
              <button onClick={() => setStage('pricing_sub')} className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-300 text-xs font-semibold cursor-pointer">
                Change Selection
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-stone-950/80 border border-stone-800 space-y-2 text-xs text-stone-300">
              <span className="font-bold text-stone-200 block">Payment Terms & Safety Guarantee:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-400" /><span>50% Advance & ඉතිරි 50% වැඩේ අවසන් වී පරීක්ෂා කිරීමෙන් පසු පමණි</span></div>
                <div className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-400" /><span>කිසිදු සැඟවුණු මාසික ගාස්තු නොමැත (Zero Hidden Recurring Fees)</span></div>
                <div className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-400" /><span>Free 1 Year Cloud SSD Hosting & Domain Included</span></div>
                <div className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-400" /><span>දින 3-5ක් ඇතුළත Live Prototype එක පරික්ෂා කිරීමේ හැකියාව</span></div>
              </div>
            </div>

            <div className="space-y-3">
              <a
                href={getCustomWhatsAppUrl('Pricing & Budget Discussion', selectedItemTitle, selectedItemPrice)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg hover:scale-[1.01] transition-all cursor-pointer"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Confirm This Budget with Founder on WhatsApp (+94 78 847 0610)</span>
              </a>

              <div className="flex items-center justify-between text-xs">
                <button onClick={handleReset} className="text-stone-400 hover:text-stone-200 underline cursor-pointer">
                  Start from Beginning
                </button>
                <button onClick={() => setIsMinimized(true)} className="text-amber-400 hover:text-amber-300 underline cursor-pointer">
                  Browse Traditional Website
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* BRANCH 5: DIRECT HUMAN-TO-HUMAN ASSISTANCE (Zero Tech Fear) */}
        {/* ========================================================================= */}
        {stage === 'human_sub' && (
          <div className="p-5 sm:p-8 space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest block">Direct Human-to-Human Support</span>
                <h3 className="text-base sm:text-lg font-extrabold text-stone-100">
                  {language === 'si' ? 'ඔබට වඩාත්ම පහසු සම්බන්ධතා ක්‍රමය තෝරන්න:' : 'Choose the Most Comfortable Way to Reach Us:'}
                </h3>
              </div>
              <button onClick={handleReset} className="text-xs text-stone-400 hover:text-stone-200 underline cursor-pointer">
                Back to 5 Options
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Option 5.1: WhatsApp Voice Note or Message */}
              <a
                href="https://wa.me/94788470610?text=Hi%20Shanthapriya,%20I%20am%20exploring%20Ravana%20Tech%20and%20would%20like%20to%20speak%20directly%20with%20you%20as%20a%20friend."
                target="_blank"
                rel="noopener noreferrer"
                className="p-3.5 rounded-xl bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/50 hover:border-emerald-400 text-left transition-all group flex flex-col justify-between cursor-pointer"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-bold text-xs text-stone-100 group-hover:text-emerald-300">
                      1. WhatsApp Voice / Chat
                    </span>
                  </div>
                  <span className="text-[11px] text-stone-400 block leading-relaxed">
                    ඔබට පහසු වෙලාවක සිංහලෙන් හෝ English වලින් voice note එකක් හෝ message එකක් එවන්න.
                  </span>
                </div>
                <span className="text-[10px] text-emerald-400 font-mono mt-2 block">+94 78 847 0610 ➔</span>
              </a>

              {/* Option 5.2: Direct Normal Phone Call */}
              <a
                href="tel:+94788470610"
                className="p-3.5 rounded-xl bg-stone-950 hover:bg-stone-900 border border-stone-800 hover:border-amber-400 text-left transition-all group flex flex-col justify-between cursor-pointer"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                    <span className="font-bold text-xs text-stone-100 group-hover:text-amber-300">
                      2. Direct Phone Call
                    </span>
                  </div>
                  <span className="text-[11px] text-stone-400 block leading-relaxed">
                    කෙළින්ම සාමාන්‍ය Call එකක් ගන්න. පෝලිම් නෑ — Founder Shanthapriya Silva සමඟම කතා කරන්න.
                  </span>
                </div>
                <span className="text-[10px] text-amber-400 font-mono mt-2 block">+94 78 847 0610 ➔</span>
              </a>

              {/* Option 5.3: 15-Min Free Google Meet Consultation */}
              <a
                href="https://wa.me/94788470610?text=Hi%20Shanthapriya,%20I%20would%20like%20to%20schedule%20a%20free%2015-minute%20Google%20Meet%20/%20Zoom%20session%20to%20discuss%20my%20website%20plan."
                target="_blank"
                rel="noopener noreferrer"
                className="p-3.5 rounded-xl bg-gradient-to-br from-sky-600/20 via-stone-950 to-stone-950 hover:from-sky-600/30 border border-sky-500/40 hover:border-sky-400 text-left transition-all group flex flex-col justify-between cursor-pointer"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <Video className="w-4 h-4 text-sky-400 shrink-0" />
                    <span className="font-bold text-xs text-stone-100 group-hover:text-sky-300">
                      3. Google Meet (15-Min Free)
                    </span>
                  </div>
                  <span className="text-[11px] text-stone-400 block leading-relaxed">
                    100% නොමිලේ සජීවී සාකච්ඡාවක්. Screen Share කරගෙන ඔබේ Project එක සජීවීව Plan කරගත හැක.
                  </span>
                </div>
                <span className="text-[10px] text-sky-400 font-mono mt-2 block">1-Click Google Meet Schedule ➔</span>
              </a>
            </div>

            {/* Option 5.4: Instant Callback Request Form */}
            <div className="p-4 sm:p-5 rounded-2xl bg-stone-950/90 border border-stone-800 space-y-3">
              <div className="flex items-center gap-2">
                <HeartHandshake className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs sm:text-sm font-bold text-stone-200">
                  4. "මට කතා කරන්න" — ඔබේ Number එක මෙතන ලියන්න (Callback Request):
                </h4>
              </div>

              <form onSubmit={handleCallbackSubmit} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    value={callbackName}
                    onChange={(e) => setCallbackName(e.target.value)}
                    placeholder="ඔබගේ නම (Your Name)"
                    className="w-full px-3 py-2.5 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:outline-none focus:border-amber-400"
                  />
                  <input
                    type="tel"
                    required
                    value={callbackPhone}
                    onChange={(e) => setCallbackPhone(e.target.value)}
                    placeholder="දුරකථන අංකය (Phone Number: e.g. 078 847 0610)"
                    className="w-full px-3 py-2.5 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                <input
                  type="text"
                  value={callbackNote}
                  onChange={(e) => setCallbackNote(e.target.value)}
                  placeholder="ඔබට අවශ්‍ය දේ කෙටියෙන් (උදා: කේක් කඩයකට වෙබ් සයිට් එකක්)"
                  className="w-full px-3 py-2.5 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:outline-none focus:border-amber-400"
                />

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-md"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Requesting...' : 'මට නොමිලේ Call එකක් ලබාදෙන්න (Request Free Call)'}</span>
                </button>
              </form>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {/* Option 5.4: Language Support */}
              <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 text-stone-400">
                <strong className="text-stone-200 block mb-1">4. භාෂා බාධක කිසිවක් නැත:</strong>
                සිංහල, English හෝ ඔබට පහසු ඕනෑම ආකාරයකින් කතා කිරීමට අප සූදානම්.
              </div>

              {/* Option 5.5: About Founder */}
              <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 text-stone-400">
                <strong className="text-stone-200 block mb-1">5. අවුරුදු 20ක ජීවිත අත්දැකීම්:</strong>
                Founder Shanthapriya Silva සතු අවුරුදු 20ක පළපුරුද්ද සමඟ සහෝදරයෙකු මෙන් ඔබට උපදෙස් ලබා දේ.
              </div>
            </div>
          </div>
        )}

        {/* CALLBACK SUCCESS */}
        {stage === 'callback_success' && (
          <div className="p-6 sm:p-10 text-center space-y-4 animate-in zoom-in-95 duration-300">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 text-emerald-400 flex items-center justify-center mx-auto text-2xl">
              ✓
            </div>
            <div className="space-y-1">
              <h3 className="text-lg sm:text-xl font-extrabold text-stone-100">
                ස්තූතියි {callbackName}! ඔබගේ Callback ඉල්ලීම සාර්ථකව ලැබුණා!
              </h3>
              <p className="text-xs sm:text-sm text-stone-400 max-w-md mx-auto">
                Founder Shanthapriya Silva විසින් නොබෝ වේලාවකින් ඔබගේ අංකයට <strong>({callbackPhone})</strong> කෙළින්ම ඇමතුමක් ලබා දෙනු ඇත.
              </p>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href={`https://wa.me/94788470610?text=Hi%20Shanthapriya,%20I%20just%20submitted%20a%20callback%20request%20as%20${encodeURIComponent(callbackName)}.`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 cursor-pointer"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Open Direct WhatsApp Now</span>
              </a>

              <button
                onClick={handleReset}
                className="px-4 py-2.5 rounded-xl bg-stone-800 text-stone-300 text-xs font-semibold hover:bg-stone-700 cursor-pointer"
              >
                Back to Reception Menu
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
